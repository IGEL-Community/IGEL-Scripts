How-to use script
====================================================
General
-------
IGEL script(s) are delivered as a zip archive. The archive has the following content:
-igel : folder containing UMS profiles
-target : folder containing scripts
-disclaimer.txt : disclaimer note
-readme.txt: Short Installation guide

Steps to deploy the scripts
------------------------------------
Follow the README.MD file included with scripts
